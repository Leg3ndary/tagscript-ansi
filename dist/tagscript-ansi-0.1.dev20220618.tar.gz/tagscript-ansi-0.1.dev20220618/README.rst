####################
sphinxcontrib-tagscript-ansi
####################

This is simply a fork to color tagscript into an ansi readable format.

Use it if you want.
