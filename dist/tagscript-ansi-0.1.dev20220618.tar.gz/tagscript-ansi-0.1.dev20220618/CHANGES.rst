0.6 (Jul 8, 2011)
=================

- Added support for background colors (thanks to James Rowe)


0.5.1 (Jul 26, 2010)
====================

- Fixed wrong ordering with nested colors


0.5 (Jul 25, 2010)
==================

- Ignore colors in non-html output


0.4.1 (Jul 21, 2010)
====================

- Fixed #2:  Installation on Windows


0.4 (May 21, 2010)
==================

- Initial release
